
         gVersions = {
           pythonversion: '2.7',
           vapiversion: '1.0.0',
           bindingsversion: '1.0.0',
           sdkversion: '6.0.0'
         }
      