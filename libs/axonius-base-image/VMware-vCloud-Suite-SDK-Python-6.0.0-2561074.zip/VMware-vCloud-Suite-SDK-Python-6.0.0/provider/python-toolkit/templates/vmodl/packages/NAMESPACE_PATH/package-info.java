${vmodl.javadoc(idlPackage)}
package ${idlPackage.name};
