#pragma once
#include <Wuapi.h>
#include <atlbase.h>
#include <iostream>
#include <string>
#include <stdio.h>
#include <comdef.h>
#include <ATLComTime.h>
#include <comutil.h>
#include <string.h>
#include "nlohmann/json.hpp"	// downloaded json package https://github.com/nlohmann/json

// for convenience
using json = nlohmann::json;

void get_available_security_updates(json * update_list, bool should_check_online, const char * const wsusscn2_filepath);