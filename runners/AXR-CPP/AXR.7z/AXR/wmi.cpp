#include "stdafx.h"
#include "wmi.h"
#include "utils.h"

// In case of case_option, Put Variant, Return True
#define PVRT(case_option, address, val) case case_option: (*address = (val)); return TRUE

// In case of case_option, Add Item to Array and Break;
#define AIAB(case_option, json_array_address, val) case case_option: (json_array_address->push_back(val)); break;

// On every wmi row that we return, if there is something we could not parse, we add an error message to a json array that will be in the following key.
#define DEBUG_VAR_NAME ("AXR_DEBUG")

IWbemServices * g_iwbem_services = NULL;
IWbemLocator * g_iwbem_locator = NULL;

/**  Uninitializes a WBEM Services pointer one time globally.

@throw std::exception on error
**/
void uninitialize_wmi()
{
	if (g_iwbem_services != NULL)
	{
		g_iwbem_services->Release();
	}

	if (g_iwbem_locator != NULL)
	{
		g_iwbem_locator->Release();
	}
}

/**  Initializes a WBEM Services pointer one time globally.

@throw std::exception on error
**/
void initialize_wmi()
{
	IWbemLocator *pLoc = 0;
	IWbemServices *pSvc = 0;
	HRESULT rc = -1;

	// We assume no multi-threaded environment currently, so no locks are required.
	if (g_iwbem_services != NULL && g_iwbem_locator != NULL) return;

	// Initialize it. Code simply taken from https://docs.microsoft.com/en-us/windows/desktop/wmisdk/creating-a-connection-to-a-wmi-namespace
	rc = CoCreateInstance(CLSID_WbemLocator, 0,
		CLSCTX_INPROC_SERVER, IID_IWbemLocator, (LPVOID *) &pLoc);
	AXREXCHR_IF_FAILED(rc, "Failed to create IWbemLocator object")

	// Connect locally to the CIMV2 (Default wmi queries namespace) namespace with the current user.
	rc = pLoc->ConnectServer(
		BSTR(L"ROOT\\CIMV2"),  //namespace
		NULL,				   // User name 
		NULL,				   // User password
		BSTR(L"MS_409"),       // Locale - American English
		NULL,				   // Security flags
		0,					   // Authority 
		0,					   // Context object 
		&pSvc);				   // IWbemServices proxy

	if (FAILED(rc))
	{
		pLoc->Release();
		throw AXREXCHR("Could not connect to WMI Local Namespace", rc);
	}

	// Set the security levels on a wmi connection
	// Code simply taken from https://docs.microsoft.com/en-us/windows/desktop/wmisdk/setting-the-security-levels-on-a-wmi-connection
	// Set the proxy so that impersonation of the client occurs.
	rc = CoSetProxyBlanket(pSvc,
		RPC_C_AUTHN_WINNT,
		RPC_C_AUTHZ_NONE,
		NULL,
		RPC_C_AUTHN_LEVEL_CALL,
		RPC_C_IMP_LEVEL_IMPERSONATE,
		NULL,
		EOAC_NONE
	);

	if (FAILED(rc))
	{
		pSvc->Release();
		pLoc->Release();
		throw AXREXCHR("Could not set Proxy Blanket on wmi object", rc);
	}

	// Success!
	g_iwbem_locator = pLoc;
	g_iwbem_services = pSvc;
}

/** Converts a Variant to a json result.

	@param result the json final result.
	@param v the variant.
	@returns true if the conversion succeeded, false otherwise.
	@throws std::exception on error
*/
BOOL variant_to_json(json * result, VARIANT v)
{
	HRESULT rc = -1;
	SAFEARRAY * varray = NULL;
	LONG varray_key_start = -1, varray_key_end = -1;
	void * array_elements = NULL;

	// We have to go through all the possible options of the variant.
	// Info:
	// https://msdn.microsoft.com/en-us/library/cc237865.aspx?f=255&MSPPError=-2147217396
	// https://docs.microsoft.com/en-us/windows/desktop/api/propidl/ns-propidl-tagpropvariant
	// https://docs.microsoft.com/en-us/windows/desktop/api/wtypes/ne-wtypes-varenum
	// https://github.com/jjfsq1985/StudyLab/blob/aba16382e2253fb8801cea7f645278305228a947/SolarServer/SolarServer/CommonTranslate.cpp
	
	switch (v.vt)
	{
	case VT_BOOL:
		// Do not put (variant.boolVal == VARIANT_TRUE) -> There is a difference between TRUE and true in c++. TRUE is a number, true is a boolean.
		if (v.boolVal == VARIANT_TRUE) *result = true;
		else *result = false;
		return TRUE;
	PVRT(VT_BSTR, result, bstr_to_string(v.bstrVal));
	PVRT(VT_I1,	result, v.cVal);
	PVRT(VT_I2,	result, v.iVal);
	PVRT(VT_I4,	result, v.lVal);
	PVRT(VT_I8,	result, v.llVal);
	PVRT(VT_UI1, result, v.bVal);
	PVRT(VT_UI2, result, v.uiVal);
	PVRT(VT_UI4, result, v.ulVal);
	PVRT(VT_UI8, result, v.ullVal);
	PVRT(VT_INT, result, v.intVal);
	PVRT(VT_UINT, result, v.uintVal);
	PVRT(VT_R4, result, v.fltVal);
	PVRT(VT_R8, result, v.dblVal);
	PVRT(VT_ERROR, result, v.scode);
	PVRT(VT_CY, result, v.cyVal.int64);
	PVRT(VT_DATE, result, v.date);

	// Same, but with ref.
	case VT_BOOL | VT_BYREF:
		// Do not put (variant.boolVal == VARIANT_TRUE) -> There is a difference between TRUE and true in c++. TRUE is a number, true is a boolean.
		if ((*v.pboolVal) == VARIANT_TRUE) *result = true;
		else *result = false;
		return TRUE;
	PVRT(VT_BSTR | VT_BYREF, result, bstr_to_string(*v.pbstrVal));
	PVRT(VT_I1 | VT_BYREF, result, *v.pcVal);
	PVRT(VT_I2 | VT_BYREF, result, *v.piVal);
	PVRT(VT_I4 | VT_BYREF, result, *v.plVal);
	PVRT(VT_I8 | VT_BYREF, result, *v.pllVal);
	PVRT(VT_UI1 | VT_BYREF, result, *v.pbVal);
	PVRT(VT_UI2 | VT_BYREF, result, *v.puiVal);
	PVRT(VT_UI4 | VT_BYREF, result, *v.pulVal);
	PVRT(VT_UI8 | VT_BYREF, result, *v.pullVal);
	PVRT(VT_INT | VT_BYREF, result, *v.pintVal);
	PVRT(VT_UINT | VT_BYREF, result, *v.puintVal);
	PVRT(VT_R4 | VT_BYREF, result, *v.pfltVal);
	PVRT(VT_R8 | VT_BYREF, result, *v.pdblVal);
	PVRT(VT_ERROR | VT_BYREF, result, *v.pscode);
	PVRT(VT_CY | VT_BYREF, result, v.pcyVal->int64);
	PVRT(VT_DATE | VT_BYREF, result, *v.pdate);
	}

	// Now we have to take care of arrays.
	if (v.vt & VT_ARRAY)
	{
		if (v.vt & VT_BYREF) {
			varray = *(v.pparray);
		}
		else {
			varray = v.parray;
		}

		// Get lower and upper bound to be able to iterate through the array
		rc = SafeArrayGetLBound(varray, 1, &varray_key_start);
		AXREXCHR_IF_FAILED(rc, "Failed to get lower bound of array");

		rc = SafeArrayGetUBound(varray, 1, &varray_key_end);
		AXREXCHR_IF_FAILED(rc, "Failed to get upper bound of array");

		rc = SafeArrayAccessData(varray, (void HUGEP**)&array_elements);
		AXREXCHR_IF_FAILED(rc, "Failed to initialize safe array access data");

		// Add all array items to the result array
		*result = json::array();

		for (int i = varray_key_start; i < varray_key_end; i++)
		{
			// Turn of the VT_ARRAY and VT_BYREF flags, so that we would be left only with the actual type.
			switch ((v.vt & ~VT_ARRAY) & ~VT_BYREF)
			{
			case VT_BOOL:
				if (((VARIANT_BOOL *)array_elements)[i] == VARIANT_TRUE) result->push_back(true);
				else result->push_back(false);
				break;
			AIAB(VT_BSTR, result, bstr_to_string(((BSTR *)array_elements)[i]));
			AIAB(VT_I1, result, ((CHAR *)array_elements)[i]);
			AIAB(VT_I2, result, ((SHORT *)array_elements)[i]);
			AIAB(VT_I4, result, ((LONG *)array_elements)[i]);
			AIAB(VT_I8, result, ((LONGLONG *)array_elements)[i]);
			AIAB(VT_UI1, result, ((UCHAR *)array_elements)[i]);
			AIAB(VT_UI2, result, ((USHORT *)array_elements)[i]);
			AIAB(VT_UI4, result, ((ULONG *)array_elements)[i]);
			AIAB(VT_UI8, result, ((ULONGLONG *)array_elements)[i]);
			AIAB(VT_INT, result, ((INT *)array_elements)[i]);
			AIAB(VT_UINT, result, ((UINT *)array_elements)[i]);
			AIAB(VT_R4, result, ((FLOAT *)array_elements)[i]);
			AIAB(VT_R8, result, ((DOUBLE *)array_elements)[i]);
			AIAB(VT_ERROR, result, ((SCODE *)array_elements)[i]);
			AIAB(VT_CY, result, ((CY *)array_elements)[i].int64);
			AIAB(VT_DATE, result, ((DATE *)array_elements)[i]);
			
			default:
				SafeArrayUnaccessData(varray);
				return FALSE;
			}
		}

		SafeArrayUnaccessData(varray);
		return TRUE;
	}

	// Unsupported data type
	return FALSE;
}

/**  Queries wmi using wql (wmi using sql) and adds the results.

	@param result the result object to which we put the result json::array.
	@param query the query
	@throw std::exception on error
**/
void get_wmi_query(json * result, std::string query)
{
	HRESULT rc = -1;
	IEnumWbemClassObject * query_result_enumerator = NULL;
	IWbemClassObject * class_object = NULL;
	CComBSTR query_as_bstr(query.c_str());	// convert std::string to BSTR
	SAFEARRAY * class_object_keys = NULL;
	LONG class_object_keys_start = -1, class_object_keys_end = -1;
	VARIANT vtProp = { 0 };
	BSTR* keys = NULL;
	char * key_as_string = NULL;
	char error_message[256] = { 0 };
	CIMTYPE pType = NULL;
	json row_in_result = NULL;
	json parsed_variant = NULL;
	json debug_messages = NULL;
	unsigned long returned_class_objects = 0;

	if (g_iwbem_services == NULL) throw AXREXC("WMI Is not initialized!");

	// Query using WQL. https://docs.microsoft.com/en-us/windows/desktop/api/wbemcli/nf-wbemcli-iwbemservices-execquery
	rc = g_iwbem_services->ExecQuery(
		BSTR(L"WQL"),
		query_as_bstr.Copy(),
		WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
		NULL,
		&query_result_enumerator
	);
	AXREXCHR_IF_FAILED(rc, "Failed to execute query '%s'", query.c_str());

	*result = json::array();
	do
	{
		// Example taken from https://docs.microsoft.com/en-us/windows/desktop/api/wbemcli/nn-wbemcli-ienumwbemclassobject
		rc = query_result_enumerator->Next(
			WBEM_INFINITE, // Timeout
			1, // Get only one object
			&class_object,
			&returned_class_objects
		);

		AXREXCHR_IF_FAILED(rc, "Failed to iterate through the query result enumerator for query '%s'", query.c_str());

		// Check if we managed to get an instance. We get one each time.
		if (returned_class_objects > 0)
		{ 
			row_in_result = json::object();
			debug_messages = json::array();

			// Now we have to get all the keys & values that were returned.
			rc = class_object->GetNames(NULL, WBEM_FLAG_ALWAYS | WBEM_FLAG_NONSYSTEM_ONLY, NULL, &class_object_keys);
			AXREXCHR_IF_FAILED(rc, "Failed to get keys for query '%s'", query.c_str());

			// Get lower and upper bound to be able to iterate through the array
			rc = SafeArrayGetLBound(class_object_keys, 1, &class_object_keys_start);
			AXREXCHR_IF_FAILED(rc, "Failed to get lower bound of names array");

			rc = SafeArrayGetUBound(class_object_keys, 1, &class_object_keys_end);
			AXREXCHR_IF_FAILED(rc, "Failed to get upper bound of names array");

			rc = SafeArrayAccessData(class_object_keys, (void HUGEP**)&keys);
			AXREXCHR_IF_FAILED(rc, "Failed to initialize safe array access data");

			// Loop through all keys and values
			for (LONG i = class_object_keys_start; i < class_object_keys_end; i++)
			{
				key_as_string = bstr_to_string(keys[i]);

				rc = class_object->Get(
					keys[i],	// name of desired property
					0,			// reserved
					&vtProp,    // pointer to Variant
					&pType,		// pointer to CIMType
					NULL		// origin of the property. can be null.
				);
				AXREXCHR_IF_FAILED(rc, "Failed getting key %s", key_as_string);

				// Finally, Parse the VARIANT and put it in the row.
				// If we have some kind of an error, like an std::exception error or an access violation, we will keep it but go and not crash.

				try {
					rc = variant_to_json(&parsed_variant, vtProp);
					if (rc == TRUE)
					{
						// Set this value if the conversion succeeded.
						row_in_result[key_as_string] = parsed_variant;
					}
					else
					{
						// At least, lets save what we couldn't parse in debug.
						if (vtProp.vt != VT_EMPTY && vtProp.vt != VT_NULL)
						{
							snprintf(error_message, sizeof(error_message) - 1, "Did not parse unsupported property %s of type %#x", key_as_string, vtProp.vt);
							debug_messages.push_back(error_message);
						}
					}

				}
				catch (const std::exception& e) {
					snprintf(error_message, sizeof(error_message) - 1, "Exception occured while parsing property %s of type %#x: %s", key_as_string, vtProp.vt, e.what());
					debug_messages.push_back(error_message);
				}
				catch (...) {
					// There is an exception here, like an access violation. Continuing.
					snprintf(error_message, sizeof(error_message) - 1, "Unknown exception occured while parsing property %s of type %#x", key_as_string, vtProp.vt);
					debug_messages.push_back(error_message);
				}

				// Clear variant.
				VariantClear(&vtProp);
			}

			if (debug_messages.size() > 0) row_in_result[DEBUG_VAR_NAME] = debug_messages;

			// Append the row to the list of results.
			result->push_back(row_in_result);

			// Best shot, do not check return code
			SafeArrayUnaccessData(class_object_keys);
			class_object->Release();
		}
	} while (returned_class_objects > 0);

	query_result_enumerator->Release();
}