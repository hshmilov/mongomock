#include "stdafx.h"
#include "utils.h"

#define HRESULT_MSG_MAX_LEN (512)

void print_to_stderr(const char * error_message, HRESULT error_code)
{
	_com_error err(error_code);
	LPCTSTR error_code_as_string = err.ErrorMessage();
	fprintf(stderr, "%s: %ws (%#lx)\n", error_message, error_code_as_string, error_code);
}

/* Takes an error message and an HRESULT error code, and returns a formatted string with the error code, plus a windows error message string
that describes this HRESULT. */
char * hresult_error_msg(const char * error_message, HRESULT error_code)
{
	char * err_msg = NULL;
	_com_error err(error_code);

	err_msg = (char *) malloc(HRESULT_MSG_MAX_LEN);

	if (err_msg == NULL) {
		return (char *) "Unable to allocate memory for error message";
	}

	LPCTSTR error_code_as_string = err.ErrorMessage();
	snprintf(err_msg, HRESULT_MSG_MAX_LEN - 1, "%s: %ws (%#lx)", error_message, error_code_as_string, error_code);

	return err_msg;
}

/* Converts BSTR (One of Windows API's types of string) to (char *)*/
char * bstr_to_string(BSTR s)
{
	if (SysStringLen(s) == 0)
	{
		return (char *)"";
	}
	else
	{
		return _com_util::ConvertBSTRToString(s);
	}
}
