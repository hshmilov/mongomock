#include "stdafx.h"
#include "com.h"
#include "utils.h"


/* Simply Uninitializes COM.
*/
void uninitialize_com()
{
	CoUninitialize();
}

/* Initialize COM. This also initializes wmi.

@throws std::exception on any error.
*/
void initialize_com()
{
	HRESULT rc = -1;

	// This Follows the instructions we have at https://docs.microsoft.com/en-us/windows/desktop/wmisdk/creating-a-wmi-application-using-c-
	// Initialize COM
	rc = CoInitializeEx(0, COINIT_MULTITHREADED);
	AXREXCHR_IF_FAILED(rc, "Failed to initialize COM");

	// Set the general COM security levels with a call to the CoInitializeSecurity interface.
	rc = CoInitializeSecurity(
		NULL,                        // Security descriptor    
		-1,                          // COM negotiates authentication service
		NULL,                        // Authentication services
		NULL,                        // Reserved
		RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication level for proxies
		RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation level for proxies
		NULL,                        // Authentication info
		EOAC_NONE,                   // Additional capabilities of the client or server
		NULL);                       // Reserved

	AXREXCHR_IF_FAILED(rc, "Failed to initialize COM Security")
}