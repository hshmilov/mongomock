#include "stdafx.h"
#include <iostream>
#include <string>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <winsock.h>
#include <windows.h>
#include "nlohmann/json.hpp"	// downloaded json package https://github.com/nlohmann/json
#include "utils.h"
#include "com.h"
#include "pm.h"
#include "wmi.h"
#pragma comment(lib, "Ws2_32.lib")

// for convenience
using json = nlohmann::json;

// WMI Can fail sometimes due to a temporary error (The most common one is  IDispatch error #3600 (80041010) -> Too many wmi requests)
#define MAX_NUMBER_OF_TRIES_FOR_EXECQUERY (3)
#define WMI_AMOUNT_TO_SLEEP_ON_ERROR (1000)

void parse_command(json * result, std::string command_type, json command_args)
{
	if (command_type == "pmonline")
		get_available_security_updates(result, TRUE, NULL);
	else if (command_type == "query" || command_type == "wmiquery")
	{
		// See that we got the expected results.
		if (command_args.size() != 1 || command_args.at(0).is_string() != TRUE)
			throw AXREXC("Invalid arguments for wmi query: %s", command_args.dump(4).c_str());

		// We can sometimes fail temporairly, mainly due to #3600 errors (too many requests to wmi)
		for (unsigned int i = 0; i < MAX_NUMBER_OF_TRIES_FOR_EXECQUERY; i++)
		{
			try
			{
				get_wmi_query(result, command_args.at(0).get<std::string>());
				return;
			}
			catch (std::exception)
			{
				// re-throw if its the last one.
				if (i == MAX_NUMBER_OF_TRIES_FOR_EXECQUERY - 1) throw;
			}
			Sleep(WMI_AMOUNT_TO_SLEEP_ON_ERROR);
		}
	}
	else
		throw AXREXC("Invalid command type %s", command_type.c_str());
}

int _main(int argc, char *argv[])
{
	try
	{
		HRESULT rc = -1;
		json input_commands = NULL;
		json final_result = json::object();
		json commands_results = json::array();
		json command_i = NULL;
		json command_args = NULL;
		std::ifstream input_file;
		std::string command_type;
		char hostname[256] = { 0 };
		WSADATA wd = { 0 };

		// Validate Arguments
		if (argc != 2) throw AXREXC("Usage: %s [path_to_commands_json]", argv[0]);

		// Initialize COM. We use it everywhere.
		initialize_com();

		// Initialize WMI. We use it almost all the time and the chances it will fail are very low.
		initialize_wmi();

		// Initilize WSA. We use it all the time to get the hostname.
		rc = WSAStartup(MAKEWORD(2, 0), &wd);
		if (rc != 0) {
			throw AXREXC("Error initializing WSA: %d", rc);
		}

		// Open the input file and read it. json::parse will throw an exception if the input is not a valid json.
		input_file.open(argv[1]);
		if (input_file.is_open())
		{
			input_commands = json::parse(input_file);
			input_file.close();
		}
		else throw AXREXC("Error opening input file %s", argv[1]);

		// Now that we have it, lets parse it.
		// The format should be the default format we use for the execution. Example of one command:
		// [{"type": "command_name", "args": ["list", "of", "params", "in", "an", "array"]}]

		if (input_commands.is_array() != TRUE) throw AXREXC("Expected input commands json to be an array");
		for (unsigned int i = 0; i < input_commands.size(); i++)
		{
			// Check that we are handling an object (dict) inside this string.
			command_i = input_commands.at(i);
			if (command_i.is_object() != TRUE)
				throw AXREXC("Expected each of the input commands type to be an object. input_commands (index %lu): \n%s", i, input_commands.dump(4).c_str());
			
			// Check existance of "type" and "args"
			if ((command_i.find("type") == command_i.end()) || (command_i.find("args") == command_i.end()))
				throw AXREXC("Expected command to have 'type' and 'args'. Instead, got \n%s", command_i.dump(4).c_str());
			
			// Check types of "type" and "args"
			if (command_i.at("type").is_string() != TRUE || command_i.at("args").is_array() != TRUE)
				throw AXREXC("Expected types 'string' for 'type' and 'array' for 'args'. Instead, got \n%s", command_i.dump(4).c_str());

			command_type = command_i.at("type").get<std::string>();
			command_args = command_i.at("args");

			// This item is legitimate! Lets move it on to the parsing stage.
			try
			{
				// do something
				commands_results[i] = json::object();
				commands_results[i]["status"] = "ok";
				parse_command(&commands_results[i]["data"], command_type, command_args);
			}
			catch (const std::exception& e)
			{
				commands_results[i]["status"] = "exception";
				commands_results[i]["data"] = e.what();
			}
		}
		
		// Get the local hostname. We need this for validation later on
		rc = gethostname(hostname, sizeof(hostname) - 1);
		if (rc != 0)
		{
			// This is a standard api call that shouldn't really fail. If it fails its a good decision to make this thing fail all.
			throw AXREXC("Failed to get hostname. return code is %d", rc);
		}
		
		// Build the final result
		final_result["status"] = "ok";
		final_result["hostname"] = hostname;
		final_result["data"] = commands_results;

		// dump the final json. 4 is for pretty dumping (identation etc)
		printf("%s", final_result.dump(4).c_str());

		try
		{
			uninitialize_wmi();
			uninitialize_com();
		}
		catch (...)
		{
			// Do nothing, That is a best try.
		}
		return 0;
	}
	catch (const std::exception& e)
	{
		fprintf(stderr, "Exception: %s. Exiting", e.what());
		return -1;
	}
	catch (...)
	{
		fprintf(stderr, "AXR threw an unknown exception. Exiting");
		return -1;
	}
}


int main(int argc, char *argv[])
{
	__try
	{
		return _main(argc, argv);
	}
	__except (true)
	{
		fprintf(stderr, "AXR threw a fatal exception: %lx. Exiting\n", GetExceptionCode());
		exit(-1);
	}
	return -1;
}