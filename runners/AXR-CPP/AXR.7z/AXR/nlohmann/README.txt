- This package was downloaded from https://github.com/nlohmann/json
to support outputting in a json format.
- It is provided in the MIT license.
- The current version here is https://github.com/nlohmann/json/releases/tag/v3.1.2