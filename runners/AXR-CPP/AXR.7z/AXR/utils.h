#pragma once

#include <Wuapi.h>
#include <atlbase.h>
#include <iostream>
#include <string>
#include <stdio.h>
#include <comdef.h>
#include <ATLComTime.h>
#include <comutil.h>
#include <string.h>
#include "AXRException.h"

char * hresult_error_msg(const char * error_message, HRESULT error_code);
void print_to_stderr(const char * error_message, HRESULT error_code);
char * bstr_to_string(BSTR s);

#define __FILE_RELATIVE__ (strrchr(__FILE__, '\\') ? strrchr(__FILE__, '\\') + 1 : __FILE__)
#define AXREXC(fmt_string, ...) (AXRException(__FILE_RELATIVE__, __LINE__, fmt_string, ##__VA_ARGS__))
#define AXREXCHR(err_message, err_code, ...) (AXRException(__FILE_RELATIVE__, __LINE__, hresult_error_msg(err_message, err_code), ##__VA_ARGS__))
#define AXREXCHR_IF_FAILED(err_code, err_message, ...) if (FAILED(err_code)) throw AXREXCHR(err_message, err_code, ##__VA_ARGS__);
