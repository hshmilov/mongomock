#include "stdafx.h"
#include "AXRException.h"

AXRException::AXRException(const char * file_path, unsigned int line_number, const char * format, ...) : std::exception() {
	va_list args;
	unsigned int written_len = -1;

	va_start(args, format);
	written_len = snprintf(error_msg, MAX_ERROR_LEN, "%s:%u ", file_path, line_number);
	vsnprintf(error_msg + written_len, MAX_ERROR_LEN, format, args);
	va_end(args);
}