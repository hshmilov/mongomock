#pragma once

#include <exception>
#include <cstdio>
#include <stdarg.h>

#define MAX_ERROR_LEN (1024)
#define HRESULT_TO_ERRSTR(code) (_com_error err(error_code);LPCTSTR error_code_as_string = err.ErrorMessage();)

class AXRException : public std::exception {
public:
	AXRException(const char * file_path, unsigned int line_number, const char * format, ...);
	virtual const char * what() const throw() { return error_msg; }
	virtual ~AXRException() throw() {};
private:
	char error_msg[MAX_ERROR_LEN];
};
