#pragma once
#include <string>
#define _WIN32_DCOM
#include <iostream>
using namespace std;
#include <windows.h>
#include <wbemidl.h>
#pragma comment(lib, "wbemuuid.lib")
#include "nlohmann/json.hpp"	// downloaded json package https://github.com/nlohmann/json

// for convenience
using json = nlohmann::json;

void uninitialize_wmi();
void initialize_wmi();
void get_wmi_query(json * result, std::string query);